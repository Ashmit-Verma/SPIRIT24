import React from "react";
import img2 from './Frame 49.png';
import img1 from './spirit.png';
import './footer.css';
import insta from './insta.png';
import fb from './fb.png';
import yt from './youtube.png';
import { Link } from "react-router-dom";

const Footer=()=>{
    return(
        <div className="footer-cont">
            <div className="first">
                <img src={img1} alt="" className="spirit-logo"/>
                <img src={img2} alt="Copyright"  className="copyright"/>
                <div className="social-media">
                    <img src={insta} alt=""  className="media-img"/>
                    <img src={yt} alt="" className="media-img" />
                    <img src={fb} alt="" className="media-img" />
                </div>

            </div>
            <div className="big-div"><div className="second">
                <div className="quick">Quick Links</div>
                <div className="links-div">
                <div className="links">Home</div>
                <div className="links">Events</div>
                <div className="links">About Us</div>
                </div>
            </div>
            <div className="second">
            <div className="quick">Contact</div>
                <div className="links-div">
                <div className="links">+91 98550505050</div>
                <div className="links">Someone at Spirit</div>
                
                </div>
            </div></div>
        </div>
    )
}

export default Footer;